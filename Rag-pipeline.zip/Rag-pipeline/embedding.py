import logging
import torch
import numpy as np
from typing import List

from transformers import AutoModel, AutoTokenizer
from sentence_transformers import SentenceTransformer


class BaseEmbedder:
    def encode(self, texts: List[str], normalize_embeddings: bool = True):
        raise NotImplementedError

    def get_sentence_embedding_dimension(self) -> int:
        raise NotImplementedError


class SentenceTransformerEmbedder(BaseEmbedder):
    def __init__(self, model_name: str):
        self.model = SentenceTransformer(model_name)

    def encode(self, texts: List[str], normalize_embeddings: bool = True):
        return self.model.encode(texts, normalize_embeddings=normalize_embeddings, show_progress_bar=False)

    def get_sentence_embedding_dimension(self) -> int:
        return self.model.get_sentence_embedding_dimension()


class QwenEmbeddingModel(BaseEmbedder):
    def __init__(self, model_name: str):
        torch_dtype = torch.float16 if torch.cuda.is_available() else torch.float32
        # Try to load the tokenizer. Some HF tokenizers (especially with fast Rust-backed
        # tokenizers) can sometimes fail due to cache corruption or format mismatches.
        # Try default (fast) first, then retry with use_fast=False. If both fail,
        # raise a clear error explaining next steps.
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
        except Exception as e_fast:
            logging.warning("AutoTokenizer fast load failed for %s: %s", model_name, e_fast)
            try:
                self.tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True, use_fast=False)
                logging.info("Loaded tokenizer with use_fast=False for %s", model_name)
            except Exception as e_no_fast:
                # Give a helpful error with remediation steps
                raise RuntimeError(
                    f"Failed to load tokenizer for model '{model_name}'.\n"
                    f"Try clearing the Hugging Face cache and re-running:\n"
                    f"  pip install \"huggingface_hub[cli]\"\n"
                    f"  hf cache delete --disable-tui\n"
                    f"Or use a smaller sentence-transformers model like 'sentence-transformers/all-MiniLM-L12-v2'.\n"
                    f"Original errors:\nFAST: {e_fast}\nNO_FAST: {e_no_fast}"
                )
        self.model = AutoModel.from_pretrained(
            model_name,
            trust_remote_code=True,
            torch_dtype=torch_dtype,
            device_map="auto",
        )
        self.model.eval()
        # Probe dimension
        with torch.no_grad():
            dummy = self.tokenizer("test", return_tensors="pt").to(self.model.device)
            out = self.model(**dummy)
            last_hidden = out.last_hidden_state
            self._dim = last_hidden.shape[-1]

    def encode(self, texts: List[str], normalize_embeddings: bool = True):
        all_vecs = []
        with torch.no_grad():
            for text in texts:
                inputs = self.tokenizer(text, return_tensors="pt", truncation=True, max_length=2048).to(self.model.device)
                out = self.model(**inputs)
                last_hidden = out.last_hidden_state  # [1, seq_len, dim]
                mask = inputs["attention_mask"].unsqueeze(-1)  # [1, seq_len, 1]
                masked = last_hidden * mask
                summed = masked.sum(dim=1)
                counts = mask.sum(dim=1).clamp(min=1)
                emb = (summed / counts).squeeze(0)
                vec = emb.detach().float().cpu().numpy()
                if normalize_embeddings:
                    norm = np.linalg.norm(vec) + 1e-12
                    vec = vec / norm
                all_vecs.append(vec)
        return np.stack(all_vecs, axis=0)

    def get_sentence_embedding_dimension(self) -> int:
        return int(self._dim)


def load_text_embedder(model_name: str) -> BaseEmbedder:
    name_lower = model_name.lower()
    if "qwen3" in name_lower and "emb" in name_lower:
        try:
            return QwenEmbeddingModel(model_name)
        except Exception as e:
            # If Qwen loader failed (common: transformers too old or custom model_type),
            # provide a helpful message and fall back to a sentence-transformers model.
            logging.error("Failed to load Qwen embedder (%s): %s", model_name, e)
            logging.info("Falling back to sentence-transformers/all-MiniLM-L12-v2 for embeddings.")
            return SentenceTransformerEmbedder("sentence-transformers/all-MiniLM-L12-v2")
    # default to sentence-transformers
    return SentenceTransformerEmbedder(model_name)


