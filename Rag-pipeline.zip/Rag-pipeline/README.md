# QuestDB RAG with Qwen3 + Qdrant

## Quickstart

1) Install dependencies
```bash
python -m venv .venv
. .venv/Scripts/Activate.ps1  # Windows PowerShell
pip install -r requirements.txt
```

2) Start Qdrant (Docker)
```bash
docker run -p 6333:6333 qdrant/qdrant
```

3) Scrape QuestDB docs to JSONL
```bash
python scraper/scrape.py --out data/questdb_docs.jsonl
```

4) Ingest into Qdrant (default: Qwen3-Embedding-0.6B)
```bash
python ingest.py --jsonl data/questdb_docs.jsonl --collection questdb_docs --recreate --model Qwen/Qwen3-Embedding-0.6B
# Or use a sentence-transformer instead
python ingest.py --jsonl data/questdb_docs.jsonl --collection questdb_docs --model BAAI/bge-small-en-v1.5
```

5) Run an example query with Qwen3-0.6B
```bash
python demo.py
```

Or manually:
```bash
python rag.py --table data/demo_table.json --question "How can I efficiently query the average temperature per device over the last hour?"
```

## Notes
- The answer is constrained to retrieved documentation. If none retrieved, it will answer: "I don't know based on the provided documentation."
- For 4-bit quantization on Windows, bitsandbytes may not be available; the script will fall back automatically.
- You can switch LLM via `--llm Qwen/Qwen3-1.7B` if you have VRAM.

## Repo layout
- `scraper/` — scrapes `https://questdb.io/docs/` and writes JSONL
- `ingest.py` — embeds with Qwen3-Embedding (or sentence-transformers) and uploads to Qdrant collection `questdb_docs`
- `rag.py` — retrieval and Qwen3 generation with strict doc-grounding prompt
- `demo.py` — runs a single E2E example
- `requirements.txt` — deps

## Production tips
- Use `--recreate` during development; omit it in CI to preserve collection between runs.
- Adjust `scraper/scrape.py --max-pages` and `--delay` to respect site load.
- Set `QDRANT_URL` env and pass via `--host` if Qdrant runs remotely.
