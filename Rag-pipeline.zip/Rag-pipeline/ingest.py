import argparse
import json
import hashlib
from typing import Iterable, List

from qdrant_client import QdrantClient
from qdrant_client.http import models as qmodels
from embedding import load_text_embedder
from utils import get_logger


DEFAULT_COLLECTION = "questdb_docs"
logger = get_logger("ingest")


def read_jsonl(path: str) -> Iterable[dict]:
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            yield json.loads(line)


def ensure_collection(client: QdrantClient, collection: str, vector_size: int, recreate: bool = False) -> None:
    exist = client.get_collections()
    names = {c.name for c in exist.collections}
    if collection in names and recreate:
        logger.info(f"Recreating existing collection '{collection}'")
        client.delete_collection(collection)
        names.remove(collection)
    if collection in names:
        return
    client.create_collection(
        collection_name=collection,
        vectors_config=qmodels.VectorParams(size=vector_size, distance=qmodels.Distance.COSINE),
    )


def make_point_id(source_url: str, section_title: str, chunk_text: str) -> int:
    h = hashlib.sha256()
    h.update(source_url.encode("utf-8"))
    h.update(b"|")
    h.update(section_title.encode("utf-8"))
    h.update(b"|")
    h.update(chunk_text.encode("utf-8"))
    # Use lower 63 bits to stay within signed 64-bit positive range
    return int.from_bytes(h.digest()[:8], "big") & ((1 << 63) - 1)


def batch(iterable: List[dict], size: int):
    for i in range(0, len(iterable), size):
        yield iterable[i : i + size]


def main():
    parser = argparse.ArgumentParser(description="Embed and upload QuestDB docs to Qdrant")
    parser.add_argument("--jsonl", default="data/questdb_docs.jsonl")
    parser.add_argument("--host", default="http://localhost:6333")
    parser.add_argument("--collection", default=DEFAULT_COLLECTION)
    parser.add_argument("--model", default="Qwen/Qwen3-Embedding-0.6B")
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--recreate", action="store_true", help="Drop and recreate the collection")
    args = parser.parse_args()

    # Load embedder (supports Qwen3-Embedding and SentenceTransformers)
    embedder = load_text_embedder(args.model)
    vector_size = embedder.get_sentence_embedding_dimension()

    # Qdrant
    client = QdrantClient(url=args.host)
    ensure_collection(client, args.collection, vector_size, recreate=args.recreate)

    # Read data
    records = list(read_jsonl(args.jsonl))
    texts = [r["chunk_text"] for r in records]
    embeddings = embedder.encode(texts, normalize_embeddings=True)

    # Upsert in batches
    points = []
    for rec, vec in zip(records, embeddings):
        payload = {
            "source_url": rec.get("source_url"),
            "title": rec.get("title"),
            "section_title": rec.get("section_title"),
            "chunk_text": rec.get("chunk_text"),
        }
        pid = make_point_id(payload["source_url"], payload["section_title"], payload["chunk_text"])
        points.append(qmodels.PointStruct(id=pid, vector=vec.tolist(), payload=payload))

    for b in batch(points, args.batch_size):
        client.upsert(collection_name=args.collection, points=b)

    logger.info(f"Ingested {len(points)} points into collection '{args.collection}'.")


if __name__ == "__main__":
    main()


