import sys
from pathlib import Path

# Ensure the parent directory is in the Python path
sys.path.append(str(Path(__file__).resolve().parent.parent))

import argparse
import json
import re
import time
from collections import deque
from dataclasses import dataclass
from typing import Iterable, List, Optional, Set, Tuple
from pathlib import Path

import requests
from bs4 import BeautifulSoup, NavigableString, Tag
from urllib.parse import urljoin, urlparse
from utils import get_logger, make_retry_session


DOCS_ROOT = "https://questdb.io/docs/"
logger = get_logger("scraper")


@dataclass
class PageChunk:
    source_url: str
    title: str
    section_title: str
    chunk_text: str


def is_same_docs(url: str) -> bool:
    try:
        u = urlparse(url)
        return u.netloc.endswith("questdb.io") and u.path.startswith("/docs")
    except Exception:
        return False


def clean_text(text: str) -> str:
    text = re.sub(r"\s+", " ", text or "").strip()
    return text


def extract_main_content(soup: BeautifulSoup) -> Optional[Tag]:
    # Prefer main or article containers commonly used in docs sites
    for selector in ["main", "article", "div[role=main]", "#main-content", ".markdown", ".content"]:
        el = soup.select_one(selector)
        if el:
            return el
    # Fallback to body
    return soup.body


def split_into_chunks(container: Tag, max_chars: int = 1200, overlap: int = 150) -> List[Tuple[str, str]]:
    """
    Produce (section_title, chunk_text) pairs.
    Strategy: group by H2/H3 headings; within each section, wrap to max_chars with overlap.
    """
    sections: List[Tuple[str, List[str]]] = []
    current_title = "Introduction"
    current_lines: List[str] = []

    def flush_section():
        nonlocal current_title, current_lines
        if current_lines:
            sections.append((current_title, current_lines))
            current_lines = []

    for node in container.descendants:
        if isinstance(node, Tag) and node.name in ("h2", "h3"):
            flush_section()
            current_title = clean_text(node.get_text(" ")) or current_title
        elif isinstance(node, Tag) and node.name in ("p", "li", "code", "pre"):
            text = clean_text(node.get_text(" "))
            if text:
                current_lines.append(text)
        elif isinstance(node, NavigableString):
            # ignore stray strings (handled by parent tags above)
            continue

    flush_section()

    chunks: List[Tuple[str, str]] = []
    for sec_title, lines in sections:
        section_text = "\n".join(lines).strip()
        if not section_text:
            continue
        if len(section_text) <= max_chars:
            chunks.append((sec_title, section_text))
            continue
        # Sliding window chunking with overlap
        start = 0
        while start < len(section_text):
            end = min(len(section_text), start + max_chars)
            chunk = section_text[start:end].strip()
            if chunk:
                chunks.append((sec_title, chunk))
            if end == len(section_text):
                break
            start = max(end - overlap, start + 1)
    return chunks


def scrape_docs(base_url: str, max_pages: int = 1000, delay_sec: float = 0.5) -> List[PageChunk]:
    session = make_retry_session()
    visited: Set[str] = set()
    q = deque([base_url])
    results: List[PageChunk] = []

    while q and len(visited) < max_pages:
        url = q.popleft()
        if url in visited:
            continue
        visited.add(url)
        try:
            resp = session.get(url, timeout=20, headers={"User-Agent": "questdb-rag-scraper/1.0"})
            if resp.status_code != 200 or not resp.headers.get("content-type", "").startswith("text/html"):
                logger.debug(f"Skip non-HTML or bad status: {url} ({resp.status_code})")
                continue
            soup = BeautifulSoup(resp.text, "lxml")

            # Discover links first to keep BFS robust even if parsing fails later
            for a in soup.find_all("a", href=True):
                href = urljoin(url, a["href"])  # resolve relative
                if is_same_docs(href) and href not in visited:
                    # Normalize: strip fragments and trailing slashes
                    parsed = urlparse(href)
                    normalized = parsed._replace(fragment="").geturl().rstrip("/")
                    if normalized not in visited:
                        q.append(normalized)

            main = extract_main_content(soup)
            if not main:
                logger.debug(f"No main content found: {url}")
                continue

            # Title
            title_tag = soup.find("h1") or soup.find("title")
            title = clean_text(title_tag.get_text(" ") if title_tag else "QuestDB Docs")

            for section_title, chunk_text in split_into_chunks(main):
                if not chunk_text:
                    continue
                results.append(PageChunk(
                    source_url=url,
                    title=title,
                    section_title=section_title,
                    chunk_text=chunk_text,
                ))
        except Exception as e:
            logger.debug(f"Error scraping {url}: {e}")
            # Be resilient; skip problematic pages
            continue
        finally:
            time.sleep(delay_sec)

    return results


def save_jsonl(chunks: Iterable[PageChunk], out_path: str) -> None:
    out_file = Path(out_path)
    out_file.parent.mkdir(parents=True, exist_ok=True)
    with open(out_file, "w", encoding="utf-8") as f:
        for c in chunks:
            f.write(json.dumps({
                "source_url": c.source_url,
                "title": c.title,
                "section_title": c.section_title,
                "chunk_text": c.chunk_text,
            }, ensure_ascii=False) + "\n")


def main():
    parser = argparse.ArgumentParser(description="Scrape QuestDB docs to JSONL")
    parser.add_argument("--base-url", default=DOCS_ROOT)
    parser.add_argument("--out", default="data/questdb_docs.jsonl")
    parser.add_argument("--max-pages", type=int, default=1500)
    parser.add_argument("--delay", type=float, default=0.4)
    args = parser.parse_args()

    chunks = scrape_docs(args.base_url.rstrip("/") + "/", max_pages=args.max_pages, delay_sec=args.delay)
    save_jsonl(chunks, args.out)
    print(f"Saved {len(chunks)} chunks to {args.out}")


if __name__ == "__main__":
    main()


