import sys
import shlex
import subprocess
import streamlit as st
import os
import requests
from pathlib import Path

PY = sys.executable or "python"

st.set_page_config(page_title="QuestDB RAG — UI", layout="wide")

def run_proc(cmd_args, placeholder, timeout=None):
    """Run process and stream combined stdout/stderr into placeholder (Streamlit element).

    cmd_args should be a list (no shell) to avoid quoting issues. Returns exit code.
    """
    placeholder.code(f"Running: {' '.join(shlex.quote(a) for a in cmd_args)}\n\n")
    proc = subprocess.Popen(cmd_args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    try:
        for line in proc.stdout:
            # append line
            prev = placeholder.container()._repr_html_() if hasattr(placeholder, "container") else None
            # update by rewriting the full text block for simplicity
            current = (placeholder._value if hasattr(placeholder, "_value") else "") + line
            placeholder.code(current)
        proc.wait(timeout=timeout)
    except Exception as e:
        proc.kill()
        placeholder.code(f"Process terminated: {e}")
        return -1
    return proc.returncode


def qdrant_health(qdrant_url: str) -> bool:
    try:
        r = requests.get(qdrant_url.rstrip("/") + "/api/version", timeout=3)
        return r.status_code == 200
    except Exception:
        return False


st.title("QuestDB RAG — Control Panel")

with st.sidebar:
    st.header("Environment")
    qdrant_url = st.text_input("Qdrant URL", value=os.environ.get("QDRANT_URL", "http://localhost:6333"))
    python_bin = st.text_input("Python executable", value=PY)
    st.markdown("---")
    st.info("Use these controls to point the UI to your local Qdrant and Python interpreter.")

tabs = st.tabs(["Status", "Scrape", "Ingest", "Query", "Logs"])

# Status tab
with tabs[0]:
    st.subheader("Service Status")
    col1, col2 = st.columns(2)
    with col1:
        ok = qdrant_health(qdrant_url)
        st.metric("Qdrant", "healthy" if ok else "unreachable")
    with col2:
        st.text("Python: %s" % python_bin)

# Scrape tab
with tabs[1]:
    st.subheader("Scrape QuestDB docs")
    out_path = st.text_input("Output JSONL", "data/questdb_docs.jsonl")
    max_pages = st.number_input("Max pages", value=1500, min_value=1, step=50)
    delay = st.number_input("Delay (s)", value=0.4, min_value=0.0, step=0.1, format="%.2f")
    if st.button("Start Scrape"):
        placeholder = st.empty()
        cmd = [python_bin, str(Path("scraper") / "scrape.py"), "--out", out_path, "--max-pages", str(int(max_pages)), "--delay", str(float(delay))]
        rc = run_proc(cmd, placeholder)
        st.success(f"Scrape finished with exit code {rc}")

# Ingest tab
with tabs[2]:
    st.subheader("Ingest into Qdrant")
    jsonl = st.text_input("JSONL input file", "data/questdb_docs.jsonl")
    collection = st.text_input("Collection name", "questdb_docs")
    embed_model = st.text_input("Embedding model", "Qwen/Qwen3-Embedding-0.6B")
    recreate = st.checkbox("Recreate collection", value=True)
    if st.button("Start Ingest"):
        placeholder = st.empty()
        cmd = [python_bin, "ingest.py", "--jsonl", jsonl, "--collection", collection, "--model", embed_model]
        if recreate:
            cmd.append("--recreate")
        rc = run_proc(cmd, placeholder)
        st.success(f"Ingest finished with exit code {rc}")

# Query tab
with tabs[3]:
    st.subheader("Run a RAG Query")
    table_file = st.text_input("Table metadata file", "data/demo_table.json")
    question = st.text_area("Question", value="How can I efficiently query the average temperature per device over the last hour?")
    top_k = st.number_input("Top K chunks", value=3, min_value=1)
    if st.button("Run Query"):
        placeholder = st.empty()
        cmd = [python_bin, "rag.py", "--table", table_file, "--question", question, "--top-k", str(int(top_k))]
        rc = run_proc(cmd, placeholder)
        st.success(f"Query finished with exit code {rc}")

# Logs tab
with tabs[4]:
    st.subheader("Helpful Tips & Logs")
    st.markdown("- Use the Status tab to verify Qdrant is reachable.\n- If model downloads fail, clear Hugging Face cache: `hf cache delete`.\n- For large models consider running ingest/rag on a GPU machine.")

st.sidebar.markdown("---")
st.sidebar.write("Streamlit UI — runs local scripts using the configured Python executable.")