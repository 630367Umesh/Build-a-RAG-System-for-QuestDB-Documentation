import argparse
import json
from typing import List, Tuple

import torch
from qdrant_client import QdrantClient
from qdrant_client.http import models as qmodels
from embedding import load_text_embedder
from transformers import AutoModelForCausalLM, AutoTokenizer
from utils import get_logger
from sentence_transformers import SentenceTransformer


DEFAULT_COLLECTION = "questdb_docs"
logger = get_logger("rag")


def build_search_query(table_meta: dict, question: str) -> str:
    schema_parts = [
        f"table {table_meta.get('table_name', '')}",
        "columns: " + ", ".join(f"{c['name']}:{c['type']}" for c in table_meta.get("columns", [])),
        f"partition_by: {table_meta.get('partition_by', '')}",
        f"wal_enabled: {table_meta.get('wal_enabled', '')}",
    ]
    return (" | ".join(schema_parts) + " | question: " + question).strip()


def retrieve_chunks(
    client: QdrantClient,
    embedder: SentenceTransformer,
    collection: str,
    query_text: str,
    top_k: int = 3,
) -> List[dict]:
    query_vec = embedder.encode([query_text], normalize_embeddings=True)[0].tolist()
    res = client.search(
        collection_name=collection,
        query_vector=query_vec,
        limit=top_k,
    )
    chunks: List[dict] = []
    for p in res:
        payload = p.payload or {}
        chunks.append({
            "chunk_text": payload.get("chunk_text", ""),
            "source_url": payload.get("source_url", ""),
            "title": payload.get("title", ""),
            "section_title": payload.get("section_title", ""),
            "score": getattr(p, "score", None),
        })
    return chunks


def format_prompt(chunks: List[dict], table_meta: dict, question: str) -> str:
    docs = "\n\n".join(f"[{i+1}] {c['title']} > {c['section_title']} ({c['source_url']})\n{c['chunk_text']}" for i, c in enumerate(chunks))
    table_json = json.dumps(table_meta, ensure_ascii=False)
    return (
        "You are an expert on QuestDB. Answer the question using ONLY the provided documentation.\n"
        "If the answer is not explicitly covered, say 'I don't know based on the provided documentation.'\n"
        f"Documentation:\n{docs}\n\n"
        f"Table Schema:\n{table_json}\n\n"
        f"Question: {question}\n"
        "Answer:"
    )


def generate_answer(model_name: str, prompt: str, device: str = "auto", load_4bit: bool = True) -> str:
    torch_dtype = torch.float16 if torch.cuda.is_available() else torch.float32
    quantization_config = None
    if load_4bit:
        try:
            from transformers import BitsAndBytesConfig

            quantization_config = BitsAndBytesConfig(load_in_4bit=True)
        except Exception:
            quantization_config = None

    tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype=torch_dtype,
        device_map="auto" if device == "auto" else None,
        trust_remote_code=True,
        quantization_config=quantization_config,
    )

    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    with torch.no_grad():
        output = model.generate(
            **inputs,
            max_new_tokens=512,
            do_sample=False,
            temperature=0.0,
            eos_token_id=tokenizer.eos_token_id,
        )
    text = tokenizer.decode(output[0], skip_special_tokens=True)
    # Return only the assistant part after the prompt
    return text[len(prompt) :].strip()


def main():
    parser = argparse.ArgumentParser(description="RAG pipeline for QuestDB docs with Qwen3")
    parser.add_argument("--collection", default=DEFAULT_COLLECTION)
    parser.add_argument("--host", default="http://localhost:6333")
    parser.add_argument("--embed-model", default="Qwen/Qwen3-Embedding-0.6B")
    parser.add_argument("--llm", default="Qwen/Qwen3-0.6B")
    parser.add_argument("--top-k", type=int, default=3)
    parser.add_argument("--table", type=str, required=True, help="Path to table metadata JSON file or JSON string")
    parser.add_argument("--question", type=str, required=True)
    parser.add_argument("--no-4bit", action="store_true")
    args = parser.parse_args()

    # Table metadata
    try:
        if args.table.strip().startswith("{"):
            table_meta = json.loads(args.table)
        else:
            with open(args.table, "r", encoding="utf-8") as f:
                table_meta = json.load(f)
    except Exception as e:
        raise SystemExit(f"Failed to load table metadata: {e}")

    # Retrieval
    client = QdrantClient(url=args.host)
    embedder = load_text_embedder(args.embed_model)
    search_query = build_search_query(table_meta, args.question)
    chunks = retrieve_chunks(client, embedder, args.collection, search_query, top_k=args.top_k)
    if not chunks:
        logger.info("No relevant documentation retrieved; answering with fallback per policy.")
        print("\n--- Retrieved Chunks ---\n")
        print("[none]")
        print("\n--- Answer ---\n")
        print("I don't know based on the provided documentation.")
        return

    # LLM
    prompt = format_prompt(chunks, table_meta, args.question)
    answer = generate_answer(args.llm, prompt, load_4bit=(not args.no_4bit))
    print("\n--- Retrieved Chunks ---")
    for i, c in enumerate(chunks, 1):
        print(f"[{i}] {c['title']} > {c['section_title']} ({c['source_url']}) | score={c.get('score')}")
    print("\n--- Answer ---\n")
    print(answer)


if __name__ == "__main__":
    main()


